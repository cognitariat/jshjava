package com.garden.restart;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //1. 처리할 버튼을 찾으세요.
        Button restart = findViewById(R.id.eat);

        //2. 버튼을 클릭했을 때, 처리할 것을 셋팅
        //컨트롤+스페이스바
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "버튼을 눌러주세요....." , Toast.LENGTH_LONG).show();
                //3. 처리할 내용은 Diet Activity를 시작
//                액티비티를 넘길 때는...
//                2-1) 액티비티를 넘길 수 있는 부품을 셋팅.
//                Intent 복사(new)해서 가지고 온 다음.
                Intent go = new Intent(getApplicationContext(), DietActivity.class);
//                현재 Activity에서 가야 할 Activity 세팅
//                2-2) Intent 부품 시작
                startActivity(go);
            }
        });

        Button restart2 = findViewById(R.id.diet);

        //2. 버튼을 클릭했을 때, 처리할 것을 셋팅
        //컨트롤+스페이스바
        restart2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "버튼을 눌러주세요....." , Toast.LENGTH_LONG).show();
                //3. 처리할 내용은 Diet Activity를 시작
//                액티비티를 넘길 때는...
//                2-1) 액티비티를 넘길 수 있는 부품을 셋팅.
//                Intent 복사(new)해서 가지고 온 다음.
                Intent go = new Intent(getApplicationContext(), RealdietActivity.class);
//                현재 Activity에서 가야 할 Activity 세팅
//                2-2) Intent 부품 시작
                startActivity(go);
            }
        });

    }
}
